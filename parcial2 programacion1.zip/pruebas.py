'''Las 2 matrices de prueba seran las siguientes:
La siguiente mastriz tiene una secuencia diagonal CCCCC en la diagonal de 
la segunda fila que empieza a la izquierda, y una secuecia CCCC horizontal
en la quinta fila
Matriz mutante: A T G C G A
                C T G T T C
                T C A T G T
                A G C A G G 
                C C C C T A
                T C A C C G

La siguiente matriz solo tiene una secuencia vertical GGGG que no alcanza
para ser mutante esta se encuentra en la primera fila, quinta columna
Matriz no mutante: A T G C G A
                   C C G T G C
                   T T A T G T
                   A G A A G G
                   C T C C T A
                   T C A C T G
'''